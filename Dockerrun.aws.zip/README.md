Workflow:
Creating a mutation or query Frontend
-Select the graphql folder
-Add the query or mutation that we want to create
-run yarn gen
-gen will generate the hook
-Then we use the custom hook

    Start Frontend /Users/justinmcintosh/Projects/mattid-crm/web `yarn dev`
    Start Server /Users/justinmcintosh/Projects/mattid-crm/server `yarn dev`
    Watch Server /Users/justinmcintosh/Projects/mattid-crm/server `yarn watch`

Server Start:
-start the postgress server
-2 termals
-both server files
-yarn dev
-yarn watch
